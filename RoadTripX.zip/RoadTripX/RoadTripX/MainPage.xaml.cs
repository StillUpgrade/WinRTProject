﻿using Bing.Maps;
using RoadTripX.Common;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Popups;


// The Basic Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234237



namespace RoadTripX
{


    /// <summary>
    /// A basic page that provides characteristics common to most applications.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private Boolean canMark = false;
        private RoadManager rm = new RoadManager();
        private int pointLimit = 0;

        private NavigationHelper navigationHelper;
        private ObservableDictionary defaultViewModel = new ObservableDictionary();
        Bing.Maps.Directions.DirectionsManager directionsManager;// = myMap.DirectionsManager;
        private Bing.Maps.Directions.Route myRoute;
        private Bing.Maps.Directions.WaypointCollection waypoints;

        /// <summary>
        /// This can be changed to a strongly typed view model.
        /// </summary>
        public ObservableDictionary DefaultViewModel
        {
            get { return this.defaultViewModel; }
        }

        /// <summary>
        /// NavigationHelper is used on each page to aid in navigation and 
        /// process lifetime management
        /// </summary>
        public NavigationHelper NavigationHelper
        {
            get { return this.navigationHelper; }
        }


        public MainPage()
        {
            this.InitializeComponent();
            this.navigationHelper = new NavigationHelper(this);
            this.navigationHelper.LoadState += navigationHelper_LoadState;
            this.navigationHelper.SaveState += navigationHelper_SaveState;
            this.myMap.PointerPressedOverride += MyMap_PointerPressedOverride;
            myMap.MapType = MapType.Birdseye;
            myMap.Width = 1920;//Windows.UI.Xaml.Window.Current.Bounds.Width;
            directionsManager = myMap.DirectionsManager;
            waypoints = new Bing.Maps.Directions.WaypointCollection();
           
        }

        /// <summary>
        /// Populates the page with content passed during navigation. Any saved state is also
        /// provided when recreating a page from a prior session.
        /// </summary>
        /// <param name="sender">
        /// The source of the event; typically <see cref="NavigationHelper"/>
        /// </param>
        /// <param name="e">Event data that provides both the navigation parameter passed to
        /// <see cref="Frame.Navigate(Type, Object)"/> when this page was initially requested and
        /// a dictionary of state preserved by this page during an earlier
        /// session. The state will be null the first time a page is visited.</param>
        private void navigationHelper_LoadState(object sender, LoadStateEventArgs e)
        {
        }

        /// <summary>
        /// Preserves state associated with this page in case the application is suspended or the
        /// page is discarded from the navigation cache.  Values must conform to the serialization
        /// requirements of <see cref="SuspensionManager.SessionState"/>.
        /// </summary>
        /// <param name="sender">The source of the event; typically <see cref="NavigationHelper"/></param>
        /// <param name="e">Event data that provides an empty dictionary to be populated with
        /// serializable state.</param>
        private void navigationHelper_SaveState(object sender, SaveStateEventArgs e)
        {
        }

        private async void pushpinTapped(object sender, Windows.UI.Xaml.Input.TappedRoutedEventArgs e)
        {
            MessageDialog dialog = new MessageDialog("Hello from Seattle.");
            await dialog.ShowAsync();
        }
        #region NavigationHelper registration

        /// The methods provided in this section are simply used to allow
        /// NavigationHelper to respond to the page's navigation methods.
        /// 
        /// Page specific logic should be placed in event handlers for the  
        /// <see cref="GridCS.Common.NavigationHelper.LoadState"/>
        /// and <see cref="GridCS.Common.NavigationHelper.SaveState"/>.
        /// The navigation parameter is available in the LoadState method 
        /// in addition to page state preserved during an earlier session.

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            navigationHelper.OnNavigatedTo(e);
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            navigationHelper.OnNavigatedFrom(e);
        }

        #endregion


        private  void Button_Click_1(object sender, Windows.UI.Xaml.Input.Pointer e)
        {
            //string sessionKey = await MyMap.GetSessionIdAsync();
            //Use Session Key
            myMap.MapType = MapType.Road;

        }
        void MyMap_PointerPressedOverride(object sender, PointerRoutedEventArgs e)
        {
            if (canMark && pointLimit < 2)
            {
                int count = 0;
                Bing.Maps.Location l = new Bing.Maps.Location();
                this.myMap.TryPixelToLocation(e.GetCurrentPoint(this.myMap).Position, out l);
                Bing.Maps.Pushpin pushpin = new Bing.Maps.Pushpin();
                pushpin.SetValue(Bing.Maps.MapLayer.PositionProperty, l);
                this.myMap.Children.Add(pushpin);
                canMark = false;
                //rm.roadTrip.Add(l);
                rm.roadTrip.Insert(count,l);

                count++;
                pointLimit++;
            }
            else{
                consoleBox.Text = "Save your route to calculate the next step !";
            }
        }
        private void CalculRoute(object sender, RoutedEventArgs e)
        {
            //myMap.PointerPressed ee = ne;
            //Location l = new Location();
            
            //Pushpin pushpin = new Pushpin();
            //pushpin.Text = "1";
            //MapLayer.SetPosition(pushpin, new Location(46.849947, -121.32168));
            //Point pts = new Point();
            //pts.X = 46.849947;
            //pts.Y = -121.32168;
            //Location lc = new Location(46.849947, -121.32168);
            
            ////myMap.SetZoomLevelAroundPoint(10.0, pts, MapAnimationDuration.Default);
            //myMap.MapType = MapType.Birdseye;
            //myMap.Children.Add(pushpin);
            GetDirections();
            //Bing.Maps.Map.;
            //Map.Children.Add(pushpin);
        }


        public async void GetDirections()
        {
            try
            {
                // Set the start and end waypoints43.2803906,5.405139
                //Bing.Maps.Location l = new Location(43.535974, 5.387947);
                //Bing.Maps.Location d = new Location(43.2803906, 5.405139);
                if (pointLimit == 2)
                {
                    int count = 0;
                    //foreach (Location loc in rm.roadTrip)
                    //{
                    //    Bing.Maps.Directions.Waypoint start = new Bing.Maps.Directions.Waypoint(loc);
                    //    waypoints.Insert(count,start);
                    //    count++;
                    //}
                    int x = rm.roadTrip.Count;
                    for (int i = 0; i < x; i++)
                    {
                        Bing.Maps.Directions.Waypoint start = new Bing.Maps.Directions.Waypoint(rm.roadTrip[i]);
                        waypoints.Add(start);
                    }



                    //Bing.Maps.Directions.Waypoint start = new Bing.Maps.Directions.Waypoint(l);
                    //Bing.Maps.Directions.Waypoint end = new Bing.Maps.Directions.Waypoint(d);



                    //Bing.Maps.Directions.Waypoint startWaypoint = new Bing.Maps.Directions.Waypoint("Seattle, WA");
                    //Bing.Maps.Directions.Waypoint endWaypoint = new Bing.Maps.Directions.Waypoint("Portland, OR");

                    //Bing.Maps.Directions.WaypointCollection waypoints = new Bing.Maps.Directions.WaypointCollection();
                    //waypoints.Add(startWaypoint);
                    //waypoints.Add(endWaypoint);

                    directionsManager.Waypoints = waypoints;


                    directionsManager.RequestOptions.DistanceUnit = Bing.Maps.Directions.DistanceUnitOption.Kilometer;

                    // Calculate route directions
                    Bing.Maps.Directions.RouteResponse response = await directionsManager.CalculateDirectionsAsync();

                    // Display the route on the map
                    directionsManager.ShowRoutePath(response.Routes[0]);
                    //directionsManager.HideRoutePath();
                    myRoute = response.Routes[0];
                    //response.Routes[0]=null;
                    double bb = response.Routes[0].TravelDistance;
                    double dd = response.Routes[0].TravelDuration;
                    resultBox.Text = bb.ToString() + "  " + response.Routes[0].DistanceUnit;
                    resultBox.Text += " / " + dd.ToString() + " " + response.Routes[0].DurationUnit;
                    rm.roadTripkm.Add(bb.ToString());
                    rm.roadTripsec.Add(dd.ToString());
                }
                else
                {
                    consoleBox.Text = "You need at less 2 points to calcul a route !";
                }
            }
            catch
            {
                consoleBox.Text = "Il n'y a pas de route reliant les deux derniers points.";
            }

        }

        private void MarkMap(object sender, RoutedEventArgs e)
        {
            //myMap.Width = 1920;
            //myMap.UpdateLayout();
            //myMap.ZoomLevel = 10;
            canMark = true;
        }

        private void TextBlock_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        private void EraseMark(object sender, RoutedEventArgs e)
        {
            rm.roadTrip = new List<Location>();
            waypoints = new Bing.Maps.Directions.WaypointCollection();
            Reset();
        }
        private void gotoReview(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Review) , rm);
        }

        private void Reset()
        {
            myMap.DirectionsManager.HideRoutePath(myMap.DirectionsManager.ActiveRoute);
            myMap.DirectionsManager.ClearActiveRoute();

            MapLayer directionsLayer = VisualTreeHelper.GetChild(VisualTreeHelper.GetChild(VisualTreeHelper.GetChild(myMap, 0), 0), 0) as MapLayer;
            directionsLayer.Children.Clear();
            myMap.Children.Clear();
            pointLimit = 0;

        }
    }
}
