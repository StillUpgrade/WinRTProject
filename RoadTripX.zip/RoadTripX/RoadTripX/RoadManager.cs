﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bing.Maps;
namespace RoadTripX
{
    class RoadManager
    {
        public List<Location> roadTrip = new List<Location>();
        public List<String> roadTripkm = new List<String>();
        public List<String> roadTripsec = new List<String>();
        public Location[] rTrip;
        public Bing.Maps.Directions.WaypointCollection waypoints;// = new Bing.Maps.Directions.WaypointCollection();

        public RoadManager()
        {
            waypoints = new Bing.Maps.Directions.WaypointCollection();
        }

        public void AddLocationToRoad(Location l)
        {
            Bing.Maps.Directions.Waypoint point = new Bing.Maps.Directions.Waypoint(l);
            waypoints.Add(point);
        }

    }
}
