﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;

namespace RoadTripX
{
    class RoamingManager
    {
        StorageFolder roamFolder = ApplicationData.Current.RoamingFolder;

        // Tp1
        //StorageFolder localFolder = ApplicationData.Current.LocalFolder;
        //await localFolder.CreateFolderAsync("Rep01");
        //// TP2
        //StorageFolder localFolder = ApplicationData.Current.LocalFolder;
        //StorageFolder folder =
        //    await localFolder.CreateFolderAsync("Rep01", CreationCollisionOption.OpenIfExists);
        //StorageFile file1 = await folder.CreateFileAsync("file1.txt", CreationCollisionOption.OpenIfExists);
        // TP 3
        //Uri uri = new Uri("ms-appdata:///local/Rep01/file1.txt");
        //var file2 = StorageFile.GetFileFromApplicationUriAsync(uri);
        // tp 4
        //Uri uri = new Uri("ms-appdata:///Assets/Logo.scale-100.png");
        //var file2 = StorageFile.GetFileFromApplicationUriAsync(uri);
    }
}
